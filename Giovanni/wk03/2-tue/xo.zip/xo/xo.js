
var mainContainer = document.querySelector('.container');
var squares = document.querySelectorAll('.square');
var rows = document.querySelectorAll('.row');
// var column1 = document.querySelectorAll('.column1')
var player1 = 'x';
var player2 = 'o';
var movesPlayer1 = [];
var movesPlayer2 = [];

mainContainer.addEventListener('click', function(event) {
    var clickedSquare;

    for (var i = 0; i < squares.length; i++) {
        // controlla il contenuto del box
        // se il box e` vuoto ed e` il box dove ho cliccato
        if (squares[i].textContent === '' && squares[i] === event.target) {
            // ricorda quale box ho cliccato
            clickedSquare = squares[i];
        } 
    }
    // se i due giocatori hanno lo stesso numero di mosse
    // il turno e` di player1
    if (movesPlayer1.length === movesPlayer2.length) {
        clickedSquare.textContent = player1; 
        movesPlayer1.push(clickedSquare);
    // se Player1 ha piu mosse di player2, vuole dire che e` il turno di player2
    } else if(movesPlayer1.length !== 0 && movesPlayer1.length > movesPlayer2.length) {
        clickedSquare.textContent = player2;
        movesPlayer2.push(clickedSquare);
    }
    // check result for each row
    for (var i = 0; i < rows.length; i++){
        checkRow(i);
    }
    // check result for each column
    // for (var i = 0; i < column1.length; i++) {
    //     checkColumn1();
    // }    


    // check result for diagonals
    
});

var checkRow = function(i) {
    var checkListX = [];
    var checkListO = [];
    var boxesRow = rows[i].querySelectorAll('.square');
    for(var i = 0; i < boxesRow.length; i++) {
        if(boxesRow[i].textContent !== '') {
            if(boxesRow[i].textContent === player1) {
                checkListX.push(boxesRow[i].textContent)
            } else if (boxesRow[i].textContent === player2) {
                checkListO.push(boxesRow[i].textContent)
            }
        }
    }
    if (checkListX.length === 3) {
        console.log('player1 win')
    }
    if (checkListO.length === 3) {
        console.log('player2 win')
    } 
}   




// mainContainer.addEventListener('click' (column1))
//     var column1Cliked = function () {
//         column1.textContent = player1;
//         column1.textContent = player2;


//     }    

// var checkColumn1 = function (i) {
//     var checkListX = [];
//     var checkListO = [];
//     var boxesColumn1 = column1[i].querySelectorAll('.column1');
//     for (var i = 0; i < boxesColumn1.length; i++) {
//         if (boxesColumn1[i].textContent !== '') {
//             if (boxesColumn1[i].textContent === player1) {
//                 checkListX.push(boxesColumn1[i].textContent)
//             } else if (boxesColumn1[i].textContent === player2) {
//                 checkListO.push(boxesColumn1[i].textContent)
//             }
//         }
//     }
//     if (checkListX.length === 3) {
//         console.log('player1 win')
//     }
//     if (checkListO.length === 3) {
//         console.log('player2 win')
//     }
// }   




 